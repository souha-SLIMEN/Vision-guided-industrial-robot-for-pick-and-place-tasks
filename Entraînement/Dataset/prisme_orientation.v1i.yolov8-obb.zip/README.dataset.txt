# prisme_orientation > 2025-12-09 10:50pm
https://universe.roboflow.com/training-cwqxq/prisme_orientation

Provided by a Roboflow user
License: CC BY 4.0

